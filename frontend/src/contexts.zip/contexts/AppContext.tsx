import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";

import { toast } from "sonner@2.0.3";

// --- Types ---
export interface User {
  id: string;
  username: string;
  password?: string;
  fullName: string;
  role: string;
  department?: string;
  status?: string;
  lastLogin?: any;
}

export interface ProductionTracker {
  id: string;
  customer: string;
  itemType: string;
  qty: number;
  startDate: string;
  finishDate: string;
  status: string;
  machineId?: string;
}

export interface WorkOrder {
  id: string;
  woNumber: string;
  projectId: string;
  projectName: string;
  itemToProduce: string;
  targetQty: number;
  completedQty?: number;
  status: 'Draft' | 'In Progress' | 'QC' | 'Completed';
  priority: 'Low' | 'Normal' | 'Urgent';
  deadline: string;
  leadTechnician: string;
  machineId?: string;
  bom?: any[];
  startDate?: string;
  endDate?: string;
}

export interface DimensionMeasurement {
  parameter: string; // H, H1, W, W1, W2, R, D, etc
  specification: string; // e.g., "75mm", "120mm"
  sample1: string;
  sample2: string;
  sample3: string;
  sample4: string;
  result: 'OK' | 'NG';
}

export interface QCInspection {
  id: string;
  tanggal: string;
  batchNo: string;
  itemNama: string;
  qtyInspected: number;
  qtyPassed: number;
  qtyRejected: number;
  inspectorName: string;
  status: 'Passed' | 'Rejected' | 'Partial';
  notes?: string;
  visualCheck: boolean;
  dimensionCheck: boolean;
  materialCheck: boolean;
  photoUrl?: string;
  woNumber?: string;
  // NEW: Inspection Report Fields
  customerName?: string;
  drawingUrl?: string;
  remark?: string;
  dimensions?: DimensionMeasurement[];
}

export interface FieldAttendanceRecord {
  id: string;
  projectId: string;
  workerId: string;
  workerName: string;
  date: string;
  checkIn: string;
  checkOut: string;
  status: 'H' | 'A' | 'I' | 'S';
}

export interface WorkingExpenseRecord {
  id: string;
  projectId: string;
  date: string;
  description: string;
  nominal: number;
  hasNota: boolean;
  remark?: string;
  category: string;
}

export interface MaterialUsageReport {
  id: string;
  projectId: string;
  reportNumber: string;
  spkNumber: string;
  date: string;
  location: string;
  customerName: string;
  items: {
    id: string;
    materialName: string;
    unit: string;
    pengambilan: number;
    terpasang: number;
    sisa: number;
    keterangan?: string;
  }[];
  preparedBy: string;
  checkedBy: string;
  approvedBy: string;
}

export interface EquipmentUsage {
  id: string;
  projectId: string;
  equipmentId: string;
  equipmentName: string;
  date: string;
  hoursUsed: number;
  operatorName: string;
  fuelConsumption?: number;
  costPerHour: number;
}

export interface Project {
  id: string;
  kodeProject?: string;
  namaProject: string;
  customer: string;
  nilaiKontrak: number;
  status: string;
  progress: number;
  endDate: string;
  budget?: any;
  boq?: any[];
  milestones?: any[];
  quotationId?: string;
  fieldAttendance?: FieldAttendanceRecord[];
  workingExpenses?: WorkingExpenseRecord[];
  materialUsageReports?: MaterialUsageReport[];
  equipmentUsage?: EquipmentUsage[];
  materialRequests?: MaterialRequest[];
  approvalStatus?: 'Pending' | 'Approved' | 'Rejected';
  approvedBy?: string;
  approvedAt?: string;
}

export interface PurchaseOrder {
  id: string;
  noPO: string;
  tanggal: string;
  supplier: string;
  total: number;
  status: 'Draft' | 'Sent' | 'Approved' | 'Received' | 'Rejected';
  projectId?: string;
  items: any[];
}

export interface Quotation {
  id: string;
  nomorQuotation: string;
  tanggal: string;
  customer: {
    nama: string;
    alamat?: string;
    pic?: string;
  };
  perihal: string;
  grandTotal: number;
  status: 'Draft' | 'Sent' | 'Approved' | 'Rejected';
  materials?: any[];
  manpower?: any[];
  consumables?: any[];
  equipment?: any[];
  notes?: any;
  dataCollectionId?: string; // Add this
  terminology?: 'RAB' | 'SOW';
  type?: 'Direct' | 'Project';
  subtotal?: number;
  ppn?: number;
  kotaPenempatan?: string;
  untukPerhatian?: string;
}

export interface StockItem {
  id: string;
  kode: string;
  nama: string;
  stok: number;
  satuan: string;
  kategori: string;
  minStock: number;
  hargaSatuan: number;
  supplier?: string;
  lokasi: string;
  lastUpdate?: string;
  expiryDate?: string;
}

export interface StockIn {
  id: string;
  noStockIn: string;
  noSuratJalan?: string;
  tanggal: string;
  type: 'Receiving' | 'Return' | 'Adjustment';
  status: 'Posted' | 'Draft';
  createdBy: string;
  items: any[];
  notes?: string;
  noPO?: string;
}

export interface StockOut {
  id: string;
  noStockOut: string;
  noWorkOrder?: string;
  projectId?: string;
  penerima: string;
  tanggal: string;
  type: 'Project Issue' | 'Sales' | 'Adjustment';
  status: 'Posted' | 'Draft';
  createdBy: string;
  items: any[];
  notes?: string;
}

export interface StockMovement {
  id: string;
  tanggal: string;
  type: 'IN' | 'OUT';
  refNo: string;
  refType: string;
  itemKode: string;
  itemNama: string;
  qty: number;
  unit: string;
  lokasi: string;
  stockBefore: number;
  stockAfter: number;
  createdBy: string;
  projectName?: string;
  projectId?: string;
  batchNo?: string;
  expiryDate?: string;
}

export interface Receiving {
  id: string;
  noReceiving: string;
  noSuratJalan: string;
  tanggal: string;
  noPO: string;
  poId: string;
  supplier: string;
  project: string;
  status: 'Pending' | 'Partial' | 'Complete' | 'Rejected';
  items: any[];
}

export interface SuratJalan {
  id: string;
  noSurat: string;
  tanggal: string;
  
  // NEW: Type Toggle
  sjType: 'Material Delivery' | 'Equipment Loan';
  
  tujuan: string;
  alamat: string;
  upPerson?: string; // NEW: untuk "UP/"
  noPO?: string;
  projectId?: string;
  sopir?: string;
  noPolisi?: string;
  pengirim?: string;
  deliveryStatus?: 'Pending' | 'On Delivery' | 'Delivered' | 'In Transit' | 'Returned';
  podName?: string;
  podTime?: string;
  items: Array<{
    namaItem: string;
    itemKode?: string; // Optional for Equipment Loan
    jumlah: number;
    satuan: string;
    batchNo?: string; // Only for Material Delivery
    keterangan?: string; // Only for Equipment Loan
  }>;
  
  // For Equipment Loan only
  expectedReturnDate?: string;
  actualReturnDate?: string;
  returnStatus?: 'Pending' | 'Partial' | 'Complete';
  
  createdAt?: string;
}

export interface BeritaAcara {
  id: string;
  noBA: string;
  tanggal: string;
  jenisBA: 'Serah Terima Barang' | 'Penerimaan Pekerjaan' | 'Inspeksi' | 'Rapat' | 'Pengembalian Alat' | 'Custom';
  
  // Parties involved
  pihakPertama: string;
  pihakPertamaJabatan?: string;
  pihakKedua: string;
  pihakKeduaJabatan?: string;
  lokasi?: string;
  
  // Content (Rich text HTML)
  contentHTML: string;
  
  // Reference documents
  refSuratJalan?: string;
  refProject?: string;
  
  // Signatures
  ttdPihakPertama?: string;
  ttdPihakKedua?: string;
  saksi1?: string;
  saksi2?: string;
  
  createdBy?: string;
  createdAt?: string;
  pihakPertamaNama?: string;
  pihakKeduaNama?: string;
}

export interface Quotation {
  id: string;
  noPenawaran: string; // Format: 11/A,PEN/GMT/IV/2025
  revisi: string; // A, B, C, D...
  tanggal: string;
  jenisQuotation: 'Jasa' | 'Material';
  
  // Client info
  kepada: string; // Nama perusahaan client
  lokasi: string; // Alamat client
  up?: string; // U.P. contact person
  
  // Document info
  lampiran?: string;
  perihal: string; // Penawaran Jasa/Material
  
  // Items - organized by sections
  sections: Array<{
    id: string;
    label: string; // I, II, III, IV...
    title: string; // Jasa Pasang, Hand Tool & Safety, etc
    items: Array<{
      id: string;
      keterangan: string;
      satuan: string;
      hargaUnit: number;
      jumlah: number;
      total: number;
    }>;
    subtotal: number;
  }>;
  
  // Financials
  totalSebelumDiskon: number;
  diskonPersen: number; // Default 2.5%
  diskonNominal: number;
  grandTotal: number;
  
  // Terms & Conditions
  terms: string[];
  
  // Status & metadata
  status: 'Draft' | 'Sent' | 'Approved' | 'Rejected' | 'Revised';
  createdBy: string;
  createdAt: string;
  sentAt?: string;
  approvedAt?: string;
  
  // Relations
  projectId?: string;
  convertedToPO?: boolean;
  poId?: string;
  
  // For Word export
  sectionsHTML?: string;
}

export interface Invoice {
  id: string;
  noInvoice: string;
  tanggal: string;
  jatuhTempo: string;
  customer: string;
  alamat: string;
  noPO: string;
  items: Array<{
    deskripsi: string;
    qty: number;
    unit: string;
    hargaSatuan: number;
    total: number;
  }>;
  subtotal: number;
  ppn: number;
  totalBayar: number;
  status: 'Unpaid' | 'Partial' | 'Paid';
  projectId?: string;
  buktiTransfer?: string;
  noKwitansi?: string;
  tanggalBayar?: string;
}

export interface ProductionReport {
  id: string;
  tanggal: string;
  shift: string;
  workshop: string;
  workerName: string;
  activity: string;
  machineNo?: string;
  startTime: string;
  endTime: string;
  outputQty: number;
  unit: string;
  remarks?: string;
  photoUrl?: string;
  woNumber?: string;
  selectedItem?: string;
}

export interface MaterialRequest {
  id: string;
  noRequest: string;
  projectName: string;
  projectId: string;
  requestedBy: string;
  requestedAt: string;
  status: 'Pending' | 'Approved' | 'Issued' | 'Rejected' | 'Ordered' | 'Delivered';
  items: Array<{
    itemKode: string;
    itemNama: string;
    qty: number;
    unit: string;
  }>;
}

export interface MaintenanceRecord {
  id: string;
  maintenanceNo: string;
  equipmentName: string;
  assetCode: string;
  maintenanceType: 'Routine' | 'Repair' | 'Overhaul';
  scheduledDate?: string;
  completedDate?: string;
  status: 'Scheduled' | 'In Progress' | 'Completed';
  cost: number;
  performedBy: string;
  notes?: string;
}

export interface DataCollection {
  id: string;
  noKoleksi: string;
  namaResponden: string;
  kategori: string; // Make it flexible to accept any category
  tanggalPengumpulan: string;
  lokasi: string;
  namaKolektor: string;
  tipePekerjaan: string;
  jenisKontrak: string;
  dataFields?: any[];
  materials?: any[];
  manpower?: any[];
  schedule?: any[];
  consumables?: any[];
  equipment?: any[];
  status: "Draft" | "Verified" | "Completed";
  notes?: string;
  priority: "Low" | "Medium" | "High" | "Urgent";
  tags?: string[];
  signature?: string;
}

export interface Payroll {
  id: string;
  month: string;
  year: number;
  totalPayroll: number;
  status: 'Pending' | 'Approved' | 'Disbursed';
  employeeCount: number;
  employeeName?: string;
  employeeId?: string;
  baseSalary?: number;
  totalOutput?: number;
  incentiveTotal?: number;
  allowanceTotal?: number;
  totalGaji?: number;
}

export interface VendorInvoice {
  id: string;
  noInvoiceVendor: string;
  supplier: string;
  noPO: string;
  totalAmount: number;
  paidAmount: number;
  status: 'Unpaid' | 'Partial' | 'Paid' | 'Overdue';
  jatuhTempo: string;
  projectId?: string;
  ppn?: number;
}

export interface SuratMasuk {
  id: string;
  noSurat: string;
  tanggalTerima: string;
  tanggalSurat: string;
  pengirim: string;
  perihal: string;
  jenisSurat: string;
  prioritas: 'Low' | 'Normal' | 'High' | 'Urgent';
  status: 'Baru' | 'Disposisi' | 'Proses' | 'Selesai';
  penerima: string;
  kategori: string;
  disposisiKe?: string;
  catatan?: string;
  projectId?: string;
  createdBy?: string;
  createdAt?: string;
}

export interface SuratKeluar {
  id: string;
  noSurat: string;
  tanggalSurat: string;
  tujuan: string;
  perihal: string;
  jenisSurat: string;
  pembuat: string;
  status: 'Draft' | 'Review' | 'Approved' | 'Sent';
  kategori: string;
  isiSurat?: string;
  projectId?: string;
  approvedBy?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  tglKirim?: string;
  notes?: string;
  templateId?: string;
}

export interface BeritaAcara {
  id: string;
  noBeritaAcara: string;
  tanggal: string;
  tempatTanggal?: string;
  jenis: 'Penyelesaian Pekerjaan' | 'Serah Terima' | 'Rapat' | 'Pemeriksaan' | 'Pemusnahan' | 'Lainnya';
  perihal: string;
  lokasi?: string;
  namaPihakPertama?: string;
  perusahaanPihakPertama?: string;
  alamatPihakPertama?: string;
  namaPihakKedua?: string;
  perusahaanPihakKedua?: string;
  alamatPihakKedua?: string;
  pihakPertama?: string;
  pihakKedua?: string;
  peserta?: any[];
  deskripsi?: string;
  status: 'Draft' | 'Final' | 'Disetujui';
  projectId?: string;
  projectName?: string;
  noPO?: string;
  tanggalPO?: string;
  tanggalPelaksanaanMulai?: string;
  tanggalPelaksanaanSelesai?: string;
  createdBy?: string;
  createdAt?: string;
  approvedBy?: string;
  approvedAt?: string;
}

export interface TemplateSurat {
  id: string;
  nama: string;
  jenisSurat: string;
  content: string;
  variables?: string[];
}

export interface Vendor {
  id: string;
  kodeVendor: string;
  namaVendor: string;
  kategori: 'Material' | 'Equipment' | 'Service' | 'Subcontractor';
  alamat?: string;
  kontak?: string;
  telepon?: string;
  email?: string;
  npwp?: string;
  paymentTerms?: string;
  status: 'Active' | 'Inactive';
  rating: number; // 1-5
  createdAt: string;
}

export interface VendorExpense {
  id: string;
  noExpense: string;
  tanggal: string;
  vendorId: string;
  vendorName: string;
  projectId?: string;
  projectName?: string;
  rabItemId?: string;
  rabItemName?: string;
  kategori: 'Material' | 'Equipment' | 'Service' | 'Transport' | 'Manpower' | 'Tools' | 'Consumables' | 'Other';
  keterangan: string;
  nominal: number;
  ppn?: number;
  totalNominal: number;
  hasKwitansi: boolean;
  kwitansiUrl?: string;
  noKwitansi?: string;
  metodeBayar: 'Cash' | 'Transfer' | 'Cheque' | 'Giro';
  status: 'Draft' | 'Pending Approval' | 'Approved' | 'Rejected' | 'Paid';
  remark?: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  rejectReason?: string;
  paidAt?: string;
  createdBy: string;
  createdAt: string;
}

// NEW: Customer & AR Management
export interface Customer {
  id: string;
  kodeCustomer: string;
  namaCustomer: string;
  alamat: string;
  kota: string;
  kontak: string;
  telepon: string;
  email: string;
  npwp?: string;
  paymentTerms: string;
  rating: number;
  status: 'Active' | 'Inactive';
  createdAt: string;
}

export interface InvoicePayment {
  id: string;
  tanggal: string;
  nominal: number;
  metodeBayar: 'Cash' | 'Transfer' | 'Cheque' | 'Giro';
  noBukti?: string;
  bankName?: string;
  remark?: string;
  createdBy: string;
  createdAt: string;
}

export interface CustomerInvoice {
  id: string;
  noInvoice: string;
  tanggal: string;
  dueDate: string;
  customerId: string;
  customerName: string;
  projectId?: string;
  projectName?: string;
  perihal: string;
  items: {
    id: string;
    deskripsi: string;
    qty: number;
    satuan: string;
    hargaSatuan: number;
    jumlah: number;
  }[];
  subtotal: number;
  ppn: number;
  pph: number;
  totalNominal: number;
  paidAmount: number;
  outstandingAmount: number;
  status: 'Draft' | 'Sent' | 'Partial Paid' | 'Paid' | 'Overdue' | 'Cancelled';
  paymentHistory: InvoicePayment[];
  noKontrak?: string;
  noPO?: string;
  termin?: string;
  remark?: string;
  createdBy: string;
  createdAt: string;
  sentAt?: string;
}

export interface Employee {
  id: string;
  employeeId: string;
  name: string;
  position: string;
  department: string;
  employmentType: 'Permanent' | 'Contract' | 'THL' | 'Internship';
  joinDate: string;
  endDate?: string;
  email: string;
  phone: string;
  address: string;
  emergencyContact: string;
  emergencyPhone: string;
  salary: number;
  status: 'Active' | 'Inactive' | 'Resigned';
  bank?: string;
  bankAccount?: string;
  npwp?: string;
  bpjsKesehatan?: string;
  bpjsKetenagakerjaan?: string;
  leaveQuota?: number;
}

export interface Attendance {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string;
  status: 'Present' | 'Late' | 'Absent' | 'Leave' | 'Sick' | 'Permission';
  checkIn?: string;
  checkOut?: string;
  workHours?: number;
  overtime?: number;
  location?: string;
  notes?: string;
}

export interface Asset {
  id: string;
  assetCode: string;
  name: string;
  category: string;
  location: string;
  status: 'Available' | 'Under Maintenance' | 'In Use' | 'Scrapped';
  condition: 'Good' | 'Fair' | 'Poor';
  purchaseDate?: string;
  purchasePrice?: number;
  rentalPrice?: number;
  lastMaintenance?: string;
  nextMaintenance?: string;
  operatorName?: string;
  projectName?: string;
  rentedTo?: string;
  notes?: string;
}

export interface ArchiveEntry {
  id: string;
  date: string;
  ref: string;
  description: string;
  amount: number;
  project: string;
  admin: string;
  type: 'AR' | 'AP' | 'PETTY' | 'BK';
  source: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: string;
  module: string;
  details: string;
  status: 'Success' | 'Failed' | 'Warning';
}

export interface AppContextType {
  projectList: Project[];
  invoiceList: Invoice[];
  stockItemList: StockItem[];
  employeeList: Employee[];
  attendanceList: Attendance[];
  workOrderList: WorkOrder[];
  productionReportList: ProductionReport[];
  productionTrackerList: ProductionTracker[];
  qcInspectionList: QCInspection[];
  stockInList: StockIn[];
  stockOutList: StockOut[];
  stockMovementList: StockMovement[];
  receivingList: Receiving[];
  suratJalanList: SuratJalan[];
  assetList: Asset[];
  quotationList: Quotation[];
  poList: PurchaseOrder[];
  vendorInvoiceList: VendorInvoice[];
  userList: User[];
  materialRequestList: MaterialRequest[];
  maintenanceList: MaintenanceRecord[];
  dataCollectionList: DataCollection[];
  payrollList: Payroll[];
  suratMasukList: SuratMasuk[];
  suratKeluarList: SuratKeluar[];
  beritaAcaraList: BeritaAcara[];
  templateSuratList: TemplateSurat[];
  archiveRegistry: ArchiveEntry[];
  auditLogs: AuditLog[];
  vendorList: Vendor[];
  expenseList: VendorExpense[];
  customerList: Customer[];
  customerInvoiceList: CustomerInvoice[];
  currentUser: User | null;
  login: (username: string) => void;
  addAuditLog: (log: Omit<AuditLog, 'id' | 'timestamp' | 'userId' | 'userName'>) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  addEmployee: (e: Employee) => void;
  updateEmployee: (id: string, updates: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;
  addAttendance: (a: Attendance) => void;
  addAttendanceBulk: (a: Attendance[]) => void;
  updateAttendance: (id: string, updates: Partial<Attendance>) => void;
  deleteAttendance: (id: string) => void;
  recordProduction: (woId: string, qty: number) => Promise<void>;
  addQCInspection: (inspection: QCInspection) => void;
  addWorkOrder: (wo: WorkOrder) => void;
  updateWorkOrder: (id: string, updates: Partial<WorkOrder>) => void;
  deleteWorkOrder: (id: string) => void;
  addStockIn: (si: StockIn) => void;
  addStockOut: (so: StockOut) => void;
  addReceiving: (rcv: Receiving) => void;
  addInvoice: (inv: Invoice) => void;
  updateInvoice: (id: string, updates: Partial<Invoice>) => void;
  addProductionReport: (report: ProductionReport) => void;
  handleProductionOutput: (woId: string, qty: number, workerName: string) => void;
  updatePO: (id: string, updates: Partial<any>) => void;
  approveProject: (id: string, ownerName: string) => void;
  updateMaterialRequest: (id: string, updates: Partial<MaterialRequest>) => void;
  issueMaterialRequest: (id: string, issuedBy: string) => void;
  addDataCollection: (dc: DataCollection) => void;
  updateDataCollection: (id: string, updates: Partial<DataCollection>) => void;
  deleteDataCollection: (id: string) => void;
  addProject: (p: Project) => void;
  deleteProject: (id: string) => void;
  addQuotation: (q: Quotation) => void;
  updateQuotation: (id: string, updates: Partial<Quotation>) => void;
  deleteQuotation: (id: string) => void;
  addVendorInvoice: (inv: VendorInvoice) => void;
  updateVendorInvoice: (id: string, updates: Partial<VendorInvoice>) => void;
  generatePayroll: (month: string, year: string) => void;
  addSuratMasuk: (s: SuratMasuk) => void;
  updateSuratMasuk: (id: string, updates: Partial<SuratMasuk>) => void;
  deleteSuratMasuk: (id: string) => void;
  addSuratKeluar: (s: SuratKeluar) => void;
  updateSuratKeluar: (id: string, updates: Partial<SuratKeluar>) => void;
  deleteSuratKeluar: (id: string) => void;
  addBeritaAcara: (ba: BeritaAcara) => void;
  updateBeritaAcara: (id: string, updates: Partial<BeritaAcara>) => void;
  deleteBeritaAcara: (id: string) => void;
  addSuratJalan: (sj: SuratJalan) => void;
  updateSuratJalan: (id: string, updates: Partial<SuratJalan>) => void;
  deleteSuratJalan: (id: string) => void;
  addAsset: (a: Asset) => void;
  addMaintenance: (m: MaintenanceRecord) => void;
  updateAsset: (id: string, updates: Partial<Asset>) => void;
  deleteAsset: (id: string) => void;
  addArchiveEntry: (entry: Omit<ArchiveEntry, 'id'>) => void;
  addEquipmentUsage: (usage: EquipmentUsage) => void;
  addMaterialRequest: (request: MaterialRequest) => void;
  updateMaterialRequestStatus: (projectId: string, requestId: string, status: MaterialRequest['status']) => void;
  applyTemplate: (templateId: string, variables: Record<string, string>) => string;
  updateReservedStock: (materials: any[], type: 'reserve' | 'release') => void;
  setStockItemList: React.Dispatch<React.SetStateAction<StockItem[]>>;
  setStockMovementList: React.Dispatch<React.SetStateAction<StockMovement[]>>;
  createStockOut: (so: StockOut) => void;
  createStockIn: (si: StockIn) => void;
  convertDataCollectionToQuotation: (dcId: string) => void;
  convertQuotationToProject: (quoId: string) => void;
  refreshAll: () => void;
  resetAllData: () => void;
  alerts: any[];
  markAlertAsRead: (id: string) => void;
  addVendor: (vendor: Vendor) => void;
  updateVendor: (id: string, updates: Partial<Vendor>) => void;
  deleteVendor: (id: string) => void;
  addExpense: (expense: VendorExpense) => void;
  updateExpense: (id: string, updates: Partial<VendorExpense>) => void;
  deleteExpense: (id: string) => void;
  approveExpense: (id: string, approver: string) => void;
  rejectExpense: (id: string, reason: string) => void;
  addCustomer: (customer: Customer) => void;
  updateCustomer: (id: string, updates: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  addCustomerInvoice: (invoice: CustomerInvoice) => void;
  updateCustomerInvoice: (id: string, updates: Partial<CustomerInvoice>) => void;
  deleteCustomerInvoice: (id: string) => void;
  addInvoicePayment: (invoiceId: string, payment: InvoicePayment) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [materialRequestList, setMaterialRequestList] = useState<MaterialRequest[]>([]);
  const [maintenanceList, setMaintenanceList] = useState<MaintenanceRecord[]>([]);
  const [invoiceList, setInvoiceList] = useState<Invoice[]>([]);
  const [stockItemList, setStockItemList] = useState<StockItem[]>([
    { id: "s1", kode: "GTP-MTR-PIP-001", nama: "Pipa Galvanis 2 Inch", stok: 120, satuan: "Batang", kategori: "Piping", minStock: 20, hargaSatuan: 450000, lokasi: "Gudang A" },
    { id: "s2", kode: "GTP-MTR-VAL-002", nama: "Valve 2 Inch", stok: 5, satuan: "Pcs", kategori: "Fitting", minStock: 10, hargaSatuan: 1200000, lokasi: "Gudang B" }
  ]);
  const [employeeList, setEmployeeList] = useState<Employee[]>([]);
  const [attendanceList, setAttendanceList] = useState<Attendance[]>([]);
  const [workOrderList, setWorkOrderList] = useState<WorkOrder[]>([]);
  const [productionReportList, setProductionReportList] = useState<ProductionReport[]>([]);
  const [productionTrackerList, setProductionTrackerList] = useState<ProductionTracker[]>([]);
  const [qcInspectionList, setQcInspectionList] = useState<QCInspection[]>([]);
  const [stockInList, setStockInList] = useState<StockIn[]>([]);
  const [stockOutList, setStockOutList] = useState<StockOut[]>([]);
  const [stockMovementList, setStockMovementList] = useState<StockMovement[]>([]);
  const [receivingList, setReceivingList] = useState<Receiving[]>([]);
  const [suratJalanList, setSuratJalanList] = useState<SuratJalan[]>([
    {
      id: 'SJ-DEMO-1',
      noSurat: 'SJ/2026/001',
      tanggal: '2026-02-10',
      sjType: 'Material Delivery',
      tujuan: 'PT. Gema Industri Indonesia',
      alamat: 'Kawasan Industri Cikarang Utama, Bekasi',
      upPerson: 'Budi Santoso',
      projectId: 'prj-demo-1',
      sopir: 'Agus Wahyudi',
      noPolisi: 'B 1234 GTP',
      pengirim: 'Gudang GTP',
      deliveryStatus: 'Delivered',
      items: [
        { namaItem: 'Pipa Galvanis 2 Inch', itemKode: 'GTP-MTR-PIP-001', jumlah: 50, satuan: 'Batang', batchNo: 'GTP/20260210/A12' },
        { namaItem: 'Valve 2 Inch', itemKode: 'GTP-MTR-VAL-002', jumlah: 12, satuan: 'Pcs', batchNo: 'GTP/20260210/B34' }
      ],
      createdAt: '2026-02-10T08:00:00Z'
    },
    {
      id: 'SJ-DEMO-2',
      noSurat: 'SJ/2026/002',
      tanggal: '2026-02-15',
      sjType: 'Equipment Loan',
      tujuan: 'PT. Daki Aluminium Industry Indonesia (Plant II)',
      alamat: 'Jalan Malig VIII Lot T2 Kawasan Industri KIIC, Teluk Jambe Barat, Karawang',
      upPerson: 'Ir. Wijaya',
      sopir: 'Dewi',
      pengirim: 'Ade Suhender',
      deliveryStatus: 'In Transit',
      expectedReturnDate: '2026-03-15',
      returnStatus: 'Pending',
      items: [
        { namaItem: 'Mixer', jumlah: 1, satuan: 'Unit', keterangan: 'Alat dipinjamkan untuk pekerjaan cor beton area plant 2' },
        { namaItem: 'Vibrator', jumlah: 2, satuan: 'Unit', keterangan: 'Setelah pekerjaan sudah selesai alat harus dikembalikan' },
        { namaItem: 'Trafo Las', jumlah: 1, satuan: 'Unit', keterangan: 'Untuk fabrikasi struktur baja' },
        { namaItem: 'Gerinda Tangan', jumlah: 3, satuan: 'Unit', keterangan: 'Grinding & polishing work' }
      ],
      createdAt: '2026-02-15T09:30:00Z'
    }
  ]);
  const [assetList, setAssetList] = useState<Asset[]>([]);
  const [quotationList, setQuotationList] = useState<Quotation[]>([]);
  const [poList, setPoList] = useState<PurchaseOrder[]>([]);
  const [vendorInvoiceList, setVendorInvoiceList] = useState<VendorInvoice[]>([]);
  const [userList, setUserList] = useState<User[]>([]);
  const [projectList, setProjectList] = useState<Project[]>([
    {
      id: "prj-demo-1",
      kodeProject: "PRJ-2026-001",
      namaProject: "Instalasi Hydrant Area B",
      customer: "PT. Gema Industri Indonesia",
      nilaiKontrak: 250000000,
      status: "In Progress",
      progress: 45,
      endDate: "2026-05-20",
      boq: [
        { materialName: "Pipa Galvanis 2 Inch", itemKode: "GTP-MTR-PIP-001", qtyEstimate: 10, qtyActual: 10, unit: "Batang", unitPrice: 400000, supplier: "Wijaya Teknik", status: "Ordered" },
        { materialName: "Fitting & Valve Package", itemKode: "GTP-MTR-FIT-001", qtyEstimate: 1, qtyActual: 0, unit: "Set", unitPrice: 2000000, supplier: "Depo Teknik", status: "Ordered" },
        { materialName: "Sewa Gerinda & Tools", itemKode: "GTP-EQ-TOOL-001", qtyEstimate: 1, qtyActual: 0, unit: "Paket", unitPrice: 600000, supplier: "Sarana Karya Mandiri", status: "Completed" }
      ],
      workingExpenses: [
        { id: "e1", projectId: "prj-demo-1", date: "2026-02-10", description: "Bensin & Makan Lembur", nominal: 450000, hasNota: true, category: "Operational" }
      ],
      materialRequests: [
        { id: "mr-1", projectId: "prj-demo-1", itemId: "GTP-MTR-PIP-001", itemName: "Pipa Galvanis 2 Inch", quantity: 10, unit: "Batang", requestedBy: "Budi Santoso", status: "Approved", requestDate: "2026-02-12", estimatedCost: 4500000 },
        { id: "mr-2", projectId: "prj-demo-1", itemId: "GTP-MTR-VAL-002", itemName: "Valve 2 Inch", quantity: 2, unit: "Pcs", requestedBy: "Dedi Kurniawan", status: "Pending", requestDate: "2026-02-13", estimatedCost: 2400000 }
      ]
    }
  ]);
  const [dataCollectionList, setDataCollectionList] = useState<DataCollection[]>([
    {
      id: "DC-001",
      noKoleksi: "KOL-2026-0001",
      namaResponden: "PT. Gema Industri Indonesia",
      kategori: "Survey",
      tanggalPengumpulan: "2026-02-13",
      lokasi: "Kawasan Industri MM2100, Bekasi",
      namaKolektor: "Budi Santoso",
      tipePekerjaan: "Pasang baru",
      jenisKontrak: "Project",
      status: "Verified",
      priority: "High",
      materials: [
        { id: "m1", materialName: "Pipa Galvanis 2 Inch", qtyEstimate: 20, qtyActual: 0, unit: "Batang", supplier: "GTP Warehouse" },
        { id: "m2", materialName: "Fitting Elbow 90 Deg", qtyEstimate: 15, qtyActual: 0, unit: "Pcs", supplier: "GTP Warehouse" }
      ],
      manpower: [
        { position: "Senior Welder", quantity: 2, duration: 3, notes: "Sertifikat 6G" },
        { position: "Helper", quantity: 4, duration: 3, notes: "General work" }
      ],
      equipment: [
        { id: "eq1", equipmentName: "Welding Machine", quantity: 2, unit: "Unit", duration: 3, durationType: "Days", supplier: "Internal" }
      ],
      notes: "Survey untuk instalasi pipa hydrant baru di area gudang B.",
      tags: ["Hydrant", "Urgent"]
    }
  ]);
  const [payrollList, setPayrollList] = useState<Payroll[]>([]);
  const [suratMasukList, setSuratMasukList] = useState<SuratMasuk[]>([]);
  const [suratKeluarList, setSuratKeluarList] = useState<SuratKeluar[]>([]);
  const [beritaAcaraList, setBeritaAcaraList] = useState<BeritaAcara[]>([
    {
      id: 'BA-DEMO-1',
      noBA: 'BA/2026/001',
      tanggal: '2026-02-10',
      jenisBA: 'Serah Terima Barang',
      pihakPertama: 'PT GEMA TEKNIK PERKASA',
      pihakPertamaJabatan: 'Direktur Utama',
      pihakKedua: 'PT. Gema Industri Indonesia',
      pihakKeduaJabatan: 'Project Manager',
      lokasi: 'Kawasan Industri Cikarang Utama, Bekasi',
      refSuratJalan: 'SJ-DEMO-1',
      contentHTML: `
        <p style="text-align: center; margin-bottom: 40px;"><strong style="font-size: 18px;">BERITA ACARA<br/>SERAH TERIMA BARANG</strong></p>
        
        <p style="margin-bottom: 20px;">Pada hari ini <strong>Senin</strong> tanggal <strong>10 Februari 2026</strong>, yang bertanda tangan di bawah ini:</p>
        
        <table style="width: 100%; margin-bottom: 30px; border: none;">
          <tr>
            <td style="width: 30%; vertical-align: top; padding: 8px 0;"><strong>Pihak Pertama</strong></td>
            <td style="width: 5%; vertical-align: top; padding: 8px 0;">:</td>
            <td style="width: 65%; vertical-align: top; padding: 8px 0;"><strong>PT GEMA TEKNIK PERKASA</strong><br/><span style="font-size: 12px; color: #666;">Dalam hal ini diwakili oleh <strong>Direktur Utama</strong></span></td>
          </tr>
          <tr>
            <td style="width: 30%; vertical-align: top; padding: 8px 0;"><strong>Pihak Kedua</strong></td>
            <td style="width: 5%; vertical-align: top; padding: 8px 0;">:</td>
            <td style="width: 65%; vertical-align: top; padding: 8px 0;"><strong>PT. Gema Industri Indonesia</strong><br/><span style="font-size: 12px; color: #666;">Dalam hal ini diwakili oleh <strong>Project Manager</strong></span></td>
          </tr>
        </table>
        
        <p style="margin-bottom: 20px;">Dengan ini menyatakan bahwa <strong>Pihak Pertama</strong> telah menyerahkan dan <strong>Pihak Kedua</strong> telah menerima barang-barang sebagai berikut:</p>
        
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px; border: 2px solid #000;">
          <thead>
            <tr style="background-color: #f0f0f0;">
              <th style="border: 1px solid #000; padding: 12px; text-align: center; font-weight: bold;">No</th>
              <th style="border: 1px solid #000; padding: 12px; text-align: left; font-weight: bold;">Nama Barang</th>
              <th style="border: 1px solid #000; padding: 12px; text-align: center; font-weight: bold;">Jumlah</th>
              <th style="border: 1px solid #000; padding: 12px; text-align: center; font-weight: bold;">Satuan</th>
              <th style="border: 1px solid #000; padding: 12px; text-align: left; font-weight: bold;">Keterangan</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">1</td>
              <td style="border: 1px solid #000; padding: 12px;"><strong>Pipa Galvanis 2 Inch</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;"><strong>50</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">Batang</td>
              <td style="border: 1px solid #000; padding: 12px;">GTP/20260210/A12</td>
            </tr>
            <tr>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">2</td>
              <td style="border: 1px solid #000; padding: 12px;"><strong>Valve 2 Inch</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;"><strong>12</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">Pcs</td>
              <td style="border: 1px solid #000; padding: 12px;">GTP/20260210/B34</td>
            </tr>
          </tbody>
        </table>
        
        <p style="margin-bottom: 20px;">Barang-barang tersebut diserahkan dalam kondisi baik dan sesuai dengan spesifikasi yang telah disepakati.</p>
        
        <p style="margin-bottom: 20px;"><strong>Referensi Dokumen:</strong> Surat Jalan No. SJ/2026/001</p>
        
        <p style="margin-bottom: 40px;">Demikian Berita Acara ini dibuat dengan sebenarnya untuk dipergunakan sebagaimana mestinya.</p>
      `,
      saksi1: 'Agus Wahyudi',
      saksi2: 'Budi Santoso',
      createdBy: 'Admin',
      createdAt: '2026-02-10T10:00:00Z'
    },
    {
      id: 'BA-DEMO-2',
      noBA: 'BA/2026/002',
      tanggal: '2026-03-15',
      jenisBA: 'Pengembalian Alat',
      pihakPertama: 'PT GEMA TEKNIK PERKASA',
      pihakPertamaJabatan: 'Direktur Operasional',
      pihakKedua: 'PT. Daki Aluminium Industry Indonesia (Plant II)',
      pihakKeduaJabatan: 'Site Manager',
      lokasi: 'Jalan Malig VIII Lot T2 Kawasan Industri KIIC, Teluk Jambe Barat, Karawang',
      refSuratJalan: 'SJ-DEMO-2',
      contentHTML: `
        <p style="text-align: center; margin-bottom: 40px;"><strong style="font-size: 18px;">BERITA ACARA<br/>PENGEMBALIAN ALAT / EQUIPMENT RETURN</strong></p>
        
        <p style="margin-bottom: 20px;">Pada hari ini <strong>Jumat</strong> tanggal <strong>15 Maret 2026</strong>, bertempat di <strong>Jalan Malig VIII Lot T2 Kawasan Industri KIIC, Teluk Jambe Barat, Karawang</strong>, yang bertanda tangan di bawah ini:</p>
        
        <table style="width: 100%; margin-bottom: 30px; border: none;">
          <tr>
            <td style="width: 30%; vertical-align: top; padding: 8px 0;"><strong>Pihak Pertama</strong></td>
            <td style="width: 5%; vertical-align: top; padding: 8px 0;">:</td>
            <td style="width: 65%; vertical-align: top; padding: 8px 0;"><strong>PT GEMA TEKNIK PERKASA</strong></td>
          </tr>
          <tr>
            <td style="width: 30%; vertical-align: top; padding: 8px 0;"><strong>Pihak Kedua</strong></td>
            <td style="width: 5%; vertical-align: top; padding: 8px 0;">:</td>
            <td style="width: 65%; vertical-align: top; padding: 8px 0;"><strong>PT. Daki Aluminium Industry Indonesia (Plant II)</strong></td>
          </tr>
        </table>
        
        <p style="margin-bottom: 20px;">Dengan ini menyatakan bahwa <strong>Pihak Kedua</strong> telah mengembalikan peralatan kepada <strong>Pihak Pertama</strong> dengan rincian sebagai berikut:</p>
        
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px; border: 2px solid #000;">
          <thead>
            <tr style="background-color: #f0f0f0;">
              <th style="border: 1px solid #000; padding: 12px; text-align: center;">No</th>
              <th style="border: 1px solid #000; padding: 12px; text-align: left;">Nama Alat / Equipment</th>
              <th style="border: 1px solid #000; padding: 12px; text-align: center;">Jumlah</th>
              <th style="border: 1px solid #000; padding: 12px; text-align: center;">Kondisi</th>
              <th style="border: 1px solid #000; padding: 12px; text-align: left;">Keterangan</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">1</td>
              <td style="border: 1px solid #000; padding: 12px;"><strong>Mixer</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;"><strong>1</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">Baik</td>
              <td style="border: 1px solid #000; padding: 12px;">Sudah dibersihkan</td>
            </tr>
            <tr>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">2</td>
              <td style="border: 1px solid #000; padding: 12px;"><strong>Vibrator</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;"><strong>2</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">Baik</td>
              <td style="border: 1px solid #000; padding: 12px;">Lengkap dengan accessories</td>
            </tr>
            <tr>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">3</td>
              <td style="border: 1px solid #000; padding: 12px;"><strong>Trafo Las</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;"><strong>1</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">Baik</td>
              <td style="border: 1px solid #000; padding: 12px;">Semua kabel normal</td>
            </tr>
            <tr>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">4</td>
              <td style="border: 1px solid #000; padding: 12px;"><strong>Gerinda Tangan</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;"><strong>3</strong></td>
              <td style="border: 1px solid #000; padding: 12px; text-align: center;">Baik</td>
              <td style="border: 1px solid #000; padding: 12px;">Sudah dibersihkan dan diperiksa</td>
            </tr>
          </tbody>
        </table>
        
        <p style="margin-bottom: 20px;"><strong>Referensi Dokumen:</strong> Surat Jalan No. SJ/2026/002</p>
        
        <p style="margin-bottom: 40px;">Demikian Berita Acara Pengembalian Alat ini dibuat untuk dipergunakan sebagaimana mestinya.</p>
      `,
      saksi1: 'Dewi',
      saksi2: 'Ir. Wijaya',
      createdBy: 'Admin',
      createdAt: '2026-03-15T14:30:00Z'
    }
  ]);
  const [templateSuratList, setTemplateSuratList] = useState<TemplateSurat[]>([]);
  const [archiveRegistry, setArchiveRegistry] = useState<ArchiveEntry[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([
    { id: "LOG-1", timestamp: new Date().toISOString(), userId: "admin", userName: "Syamsudin", action: "BAST Approved", module: "Compliance", details: "Menyetujui BAST Proyek Instalasi Hydrant", status: "Success" },
    { id: "LOG-2", timestamp: new Date(Date.now() - 3600000).toISOString(), userId: "manager", userName: "Budi", action: "Invoice Issued", module: "Commercial", details: "Menerbitkan Invoice INV/2026/042", status: "Success" },
    { id: "LOG-3", timestamp: new Date(Date.now() - 7200000).toISOString(), userId: "admin", userName: "Syamsudin", action: "User Role Updated", module: "Settings", details: "Mengubah akses user Dedi menjadi Warehouse", status: "Warning" }
  ]);
  
  // NEW: Vendor & Expense Management
  const [vendorList, setVendorList] = useState<Vendor[]>([
    {
      id: 'VND-001',
      kodeVendor: 'VND-001',
      namaVendor: 'Wijaya Teknik',
      kategori: 'Material',
      alamat: 'Jl. Raya Narogong KM 18, Cileungsi',
      kontak: 'Bpk. Wijaya',
      telepon: '021-12345678',
      status: 'Active',
      rating: 5,
      createdAt: '2026-01-01T00:00:00Z'
    },
    {
      id: 'VND-002',
      kodeVendor: 'VND-002',
      namaVendor: 'Depo Teknik',
      kategori: 'Material',
      alamat: 'Cileungsi Industrial Estate',
      kontak: 'Ibu Siti',
      telepon: '021-87654321',
      status: 'Active',
      rating: 4,
      createdAt: '2026-01-05T00:00:00Z'
    },
    {
      id: 'VND-003',
      kodeVendor: 'VND-003',
      namaVendor: 'Sarana Karya Mandiri',
      kategori: 'Equipment',
      alamat: 'Bogor Trade Center',
      kontak: 'Bpk. Ahmad',
      telepon: '0251-111222',
      status: 'Active',
      rating: 4,
      createdAt: '2026-01-10T00:00:00Z'
    }
  ]);
  
  const [expenseList, setExpenseList] = useState<VendorExpense[]>([
    {
      id: 'EXP-001',
      noExpense: 'EXP/2026/02/001',
      tanggal: '2026-02-15',
      vendorId: 'VND-001',
      vendorName: 'Wijaya Teknik',
      projectId: 'prj-demo-1',
      projectName: 'Instalasi Hydrant Area B',
      rabItemId: 'GTP-MTR-PIP-001',
      rabItemName: 'Pipa Galvanis 2 Inch',
      kategori: 'Material',
      keterangan: 'Pembelian pipa galvanis 2" - 10 batang',
      nominal: 333350,
      ppn: 0,
      totalNominal: 333350,
      hasKwitansi: false,
      metodeBayar: 'Cash',
      status: 'Pending Approval',
      createdBy: 'Admin',
      createdAt: '2026-02-15T08:30:00Z'
    },
    {
      id: 'EXP-002',
      noExpense: 'EXP/2026/02/002',
      tanggal: '2026-02-16',
      vendorId: 'VND-002',
      vendorName: 'Depo Teknik',
      projectId: 'prj-demo-1',
      projectName: 'Instalasi Hydrant Area B',
      rabItemId: 'GTP-MTR-FIT-001',
      rabItemName: 'Fitting & Valve Package',
      kategori: 'Material',
      keterangan: 'Fitting, valve, dan perlengkapan instalasi',
      nominal: 1942700,
      ppn: 0,
      totalNominal: 1942700,
      hasKwitansi: false,
      metodeBayar: 'Transfer',
      status: 'Approved',
      approvedBy: 'Syamsudin',
      approvedAt: '2026-02-16T14:00:00Z',
      createdBy: 'Admin',
      createdAt: '2026-02-16T09:00:00Z'
    },
    {
      id: 'EXP-003',
      noExpense: 'EXP/2026/02/003',
      tanggal: '2026-02-17',
      vendorId: 'VND-003',
      vendorName: 'Sarana Karya Mandiri',
      projectId: 'prj-demo-1',
      projectName: 'Instalasi Hydrant Area B',
      rabItemId: 'GTP-EQ-TOOL-001',
      rabItemName: 'Sewa Gerinda & Tools',
      kategori: 'Tools',
      keterangan: 'Sewa gerinda dan tools instalasi',
      nominal: 500000,
      ppn: 0,
      totalNominal: 500000,
      hasKwitansi: false,
      metodeBayar: 'Cash',
      status: 'Paid',
      approvedBy: 'Syamsudin',
      approvedAt: '2026-02-17T10:00:00Z',
      paidAt: '2026-02-17T15:00:00Z',
      createdBy: 'Admin',
      createdAt: '2026-02-17T08:00:00Z'
    }
  ]);
  
  // NEW: Customer & AR Management
  const [customerList, setCustomerList] = useState<Customer[]>([
    {
      id: 'CUST-001',
      kodeCustomer: 'CUST-001',
      namaCustomer: 'PT. Cemindo Gemilang',
      alamat: 'Kawasan Industri Jababeka, Cikarang',
      kota: 'Bekasi',
      kontak: 'Bpk. Santoso',
      telepon: '021-89123456',
      email: 'santoso@cemindo.co.id',
      npwp: '01.234.567.8-901.000',
      paymentTerms: 'NET 30',
      rating: 5,
      status: 'Active',
      createdAt: '2024-01-01T00:00:00Z'
    },
    {
      id: 'CUST-002',
      kodeCustomer: 'CUST-002',
      namaCustomer: 'PT. Kaltim Prima Coal',
      alamat: 'Sangatta, Kalimantan Timur',
      kota: 'Sangatta',
      kontak: 'Ibu Dian',
      telepon: '0549-123456',
      email: 'procurement@kpc.co.id',
      npwp: '02.345.678.9-012.000',
      paymentTerms: 'NET 45',
      rating: 5,
      status: 'Active',
      createdAt: '2024-02-15T00:00:00Z'
    },
    {
      id: 'CUST-003',
      kodeCustomer: 'CUST-003',
      namaCustomer: 'PT. Daiki Aluminium Industry Indonesia',
      alamat: 'KIIC Karawang',
      kota: 'Karawang',
      kontak: 'Mr. Tanaka',
      telepon: '0267-456789',
      email: 'purchasing@daiki.co.id',
      npwp: '03.456.789.0-123.000',
      paymentTerms: 'NET 30',
      rating: 4,
      status: 'Active',
      createdAt: '2024-03-01T00:00:00Z'
    },
    {
      id: 'CUST-004',
      kodeCustomer: 'CUST-004',
      namaCustomer: 'PT. Gema Industri Indonesia',
      alamat: 'Kawasan Industri Cikarang Utama',
      kota: 'Bekasi',
      kontak: 'Bpk. Budi',
      telepon: '021-98765432',
      email: 'budi@gema.co.id',
      paymentTerms: 'NET 30',
      rating: 5,
      status: 'Active',
      createdAt: '2024-01-15T00:00:00Z'
    }
  ]);

  const [customerInvoiceList, setCustomerInvoiceList] = useState<CustomerInvoice[]>([
    {
      id: 'INV-2024-001',
      noInvoice: '105/TAG/GMT/IV/2024',
      tanggal: '2024-04-15',
      dueDate: '2024-05-15',
      customerId: 'CUST-001',
      customerName: 'PT. Cemindo Gemilang',
      projectId: 'prj-demo-1',
      projectName: 'Instalasi Hydrant Area B',
      perihal: 'Tagihan Pekerjaan Instalasi Hydrant Termin 1',
      items: [
        {
          id: 'ITEM-1',
          deskripsi: 'Pekerjaan Instalasi Pipa Hydrant',
          qty: 1,
          satuan: 'Paket',
          hargaSatuan: 350000000,
          jumlah: 350000000
        }
      ],
      subtotal: 350000000,
      ppn: 38500000,
      pph: 0,
      totalNominal: 388500000,
      paidAmount: 0,
      outstandingAmount: 388500000,
      status: 'Sent',
      paymentHistory: [],
      termin: 'Termin 1 (100%)',
      createdBy: 'Admin',
      createdAt: '2024-04-15T08:00:00Z',
      sentAt: '2024-04-15T09:00:00Z'
    },
    {
      id: 'INV-2024-002',
      noInvoice: '114/TAG/GMT/IV/2024',
      tanggal: '2024-04-20',
      dueDate: '2024-05-20',
      customerId: 'CUST-001',
      customerName: 'PT. Cemindo Gemilang',
      perihal: 'Tagihan Maintenance Bulanan April 2024',
      items: [
        {
          id: 'ITEM-2',
          deskripsi: 'Maintenance Equipment',
          qty: 1,
          satuan: 'Bulan',
          hargaSatuan: 15540000,
          jumlah: 15540000
        }
      ],
      subtotal: 15540000,
      ppn: 0,
      pph: 0,
      totalNominal: 15540000,
      paidAmount: 0,
      outstandingAmount: 15540000,
      status: 'Sent',
      paymentHistory: [],
      createdBy: 'Admin',
      createdAt: '2024-04-20T08:00:00Z',
      sentAt: '2024-04-20T10:00:00Z'
    },
    {
      id: 'INV-2025-001',
      noInvoice: '001/TAG/GMT/I/2025',
      tanggal: '2025-01-10',
      dueDate: '2025-02-09',
      customerId: 'CUST-002',
      customerName: 'PT. Kaltim Prima Coal',
      perihal: 'Tagihan Supply Material Piping',
      items: [
        {
          id: 'ITEM-3',
          deskripsi: 'Pipa Carbon Steel 6"',
          qty: 200,
          satuan: 'Meter',
          hargaSatuan: 850000,
          jumlah: 170000000
        },
        {
          id: 'ITEM-4',
          deskripsi: 'Fitting & Valve Package',
          qty: 1,
          satuan: 'Set',
          hargaSatuan: 45000000,
          jumlah: 45000000
        }
      ],
      subtotal: 215000000,
      ppn: 23650000,
      pph: 4300000,
      totalNominal: 234350000,
      paidAmount: 100000000,
      outstandingAmount: 134350000,
      status: 'Partial Paid',
      paymentHistory: [
        {
          id: 'PAY-001',
          tanggal: '2025-02-01',
          nominal: 100000000,
          metodeBayar: 'Transfer',
          noBukti: 'TRF/2025/001',
          bankName: 'BCA',
          createdBy: 'Finance',
          createdAt: '2025-02-01T14:30:00Z'
        }
      ],
      termin: 'Termin 1 (50%)',
      createdBy: 'Admin',
      createdAt: '2025-01-10T08:00:00Z',
      sentAt: '2025-01-10T09:00:00Z'
    },
    {
      id: 'INV-2025-002',
      noInvoice: '002/TAG/GMT/I/2025',
      tanggal: '2025-01-15',
      dueDate: '2025-02-14',
      customerId: 'CUST-003',
      customerName: 'PT. Daiki Aluminium Industry Indonesia',
      perihal: 'Tagihan Fabrikasi Struktur Baja',
      items: [
        {
          id: 'ITEM-5',
          deskripsi: 'Fabrikasi & Instalasi Struktur Baja',
          qty: 1,
          satuan: 'Lot',
          hargaSatuan: 285000000,
          jumlah: 285000000
        }
      ],
      subtotal: 285000000,
      ppn: 31350000,
      pph: 0,
      totalNominal: 316350000,
      paidAmount: 316350000,
      outstandingAmount: 0,
      status: 'Paid',
      paymentHistory: [
        {
          id: 'PAY-002',
          tanggal: '2025-02-10',
          nominal: 316350000,
          metodeBayar: 'Transfer',
          noBukti: 'TRF/2025/002',
          bankName: 'Mandiri',
          createdBy: 'Finance',
          createdAt: '2025-02-10T11:00:00Z'
        }
      ],
      createdBy: 'Admin',
      createdAt: '2025-01-15T08:00:00Z',
      sentAt: '2025-01-15T09:00:00Z'
    },
    {
      id: 'INV-2026-001',
      noInvoice: '001/TAG/GMT/II/2026',
      tanggal: '2026-02-01',
      dueDate: '2026-03-03',
      customerId: 'CUST-004',
      customerName: 'PT. Gema Industri Indonesia',
      projectId: 'prj-demo-1',
      projectName: 'Instalasi Hydrant Area B',
      perihal: 'Progress Billing - Instalasi Hydrant',
      items: [
        {
          id: 'ITEM-6',
          deskripsi: 'Progress Pekerjaan 45%',
          qty: 1,
          satuan: 'LS',
          hargaSatuan: 112500000,
          jumlah: 112500000
        }
      ],
      subtotal: 112500000,
      ppn: 12375000,
      pph: 0,
      totalNominal: 124875000,
      paidAmount: 0,
      outstandingAmount: 124875000,
      status: 'Sent',
      paymentHistory: [],
      termin: 'Progress 45%',
      noKontrak: 'SPK/2026/001',
      createdBy: 'Admin',
      createdAt: '2026-02-01T08:00:00Z',
      sentAt: '2026-02-01T10:00:00Z'
    }
  ]);
  
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [alerts, setAlerts] = useState<any[]>([]);

  const addAuditLog = (log: Omit<AuditLog, 'id' | 'timestamp' | 'userId' | 'userName'>) => {
    const newLog: AuditLog = {
      ...log,
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser?.id || 'System',
      userName: currentUser?.fullName || 'System'
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const markAlertAsRead = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'Read' } : a));
  };

  // Stock Alert Generator
  useEffect(() => {
    const stockAlerts = stockItemList
      .filter(item => item.stok <= item.minStock)
      .map(item => ({
        id: `STK-ALERT-${item.id}`,
        type: 'Inventory',
        title: 'Low Stock Warning',
        message: `Material ${item.nama} (${item.kode}) mencapai batas minimum (${item.stok} ${item.satuan})`,
        status: 'Unread',
        severity: 'High',
        timestamp: new Date().toISOString()
      }));
    
    setAlerts(prev => {
      const existingIds = new Set(prev.map(a => a.id));
      const newAlerts = stockAlerts.filter(a => !existingIds.has(a.id));
      return [...prev, ...newAlerts];
    });
  }, [stockItemList]);

  const addArchiveEntry = (entry: Omit<ArchiveEntry, 'id'>) => {
    const newEntry = { ...entry, id: `REC-${Date.now()}` };
    setArchiveRegistry(prev => [newEntry, ...prev]);
  };

  const login = (username: string) => {
    const user = userList.find(u => u.username === username);
    if (user) {
      setCurrentUser(user);
      toast.success(`Welcome back, ${user.fullName}`);
    } else {
      toast.error("User not found");
    }
  };

  const updateUser = (id: string, updates: Partial<User>) => setUserList(prev => prev.map(u => u.id === id ? { ...u, ...updates } : u));
  const updateProject = (id: string, updates: Partial<Project>) => setProjectList(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  const addEmployee = (e: Employee) => setEmployeeList(prev => [...prev, e]);
  const updateEmployee = (id: string, updates: Partial<Employee>) => setEmployeeList(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
  const deleteEmployee = (id: string) => setEmployeeList(prev => prev.filter(e => e.id !== id));
  const addAttendance = (a: Attendance) => setAttendanceList(prev => [...prev, a]);
  const addAttendanceBulk = (a: Attendance[]) => setAttendanceList(prev => [...prev, ...a]);
  const updateAttendance = (id: string, updates: Partial<Attendance>) => setAttendanceList(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
  const deleteAttendance = (id: string) => setAttendanceList(prev => prev.filter(a => a.id !== id));
  const addQCInspection = (inspection: QCInspection) => setQcInspectionList(prev => [...prev, inspection]);
  const addWorkOrder = (wo: WorkOrder) => setWorkOrderList(prev => [...prev, wo]);
  const updateWorkOrder = (id: string, updates: Partial<WorkOrder>) => setWorkOrderList(prev => prev.map(wo => wo.id === id ? { ...wo, ...updates } : wo));
  const deleteWorkOrder = (id: string) => setWorkOrderList(prev => prev.filter(wo => wo.id !== id));

  // --- Consolidated Stock Logic (Zero Re-typing) ---
  const createStockOut = (so: StockOut) => {
    setStockOutList(prev => [...prev, so]);
    
    const updatedInventory = [...stockItemList];
    const newMovements: StockMovement[] = [];
    
    so.items.forEach(item => {
      const idx = updatedInventory.findIndex(i => i.kode === item.kode || i.nama === item.nama);
      if (idx !== -1) {
        const stockBefore = updatedInventory[idx].stok;
        updatedInventory[idx] = { ...updatedInventory[idx], stok: stockBefore - item.qty, lastUpdate: new Date().toISOString() };
        
        newMovements.push({
          id: `MOV-${Date.now()}-${item.kode}`,
          tanggal: so.tanggal,
          type: 'OUT',
          refNo: so.noStockOut,
          refType: 'Stock Out',
          itemKode: updatedInventory[idx].kode,
          itemNama: updatedInventory[idx].nama,
          qty: item.qty,
          unit: item.satuan || updatedInventory[idx].satuan,
          lokasi: updatedInventory[idx].lokasi,
          stockBefore: stockBefore,
          stockAfter: stockBefore - item.qty,
          createdBy: so.createdBy,
          projectId: so.projectId
        });
      }
    });

    setStockItemList(updatedInventory);
    setStockMovementList(prev => [...newMovements, ...prev]);
    addAuditLog({ action: 'STOCK_OUT', module: 'Warehouse', details: `Stock out ${so.noStockOut} processed`, status: 'Success' });
  };

  const createStockIn = (si: StockIn) => {
    setStockInList(prev => [...prev, si]);
    
    const updatedInventory = [...stockItemList];
    const newMovements: StockMovement[] = [];
    
    si.items.forEach(item => {
      const idx = updatedInventory.findIndex(i => i.kode === item.kode || i.nama === item.nama);
      if (idx !== -1) {
        const stockBefore = updatedInventory[idx].stok;
        updatedInventory[idx] = { ...updatedInventory[idx], stok: stockBefore + item.qty, lastUpdate: new Date().toISOString() };
        
        newMovements.push({
          id: `MOV-${Date.now()}-${item.kode}`,
          tanggal: si.tanggal,
          type: 'IN',
          refNo: si.noStockIn,
          refType: 'Stock In',
          itemKode: updatedInventory[idx].kode,
          itemNama: updatedInventory[idx].nama,
          qty: item.qty,
          unit: item.satuan || updatedInventory[idx].satuan,
          lokasi: updatedInventory[idx].lokasi,
          stockBefore: stockBefore,
          stockAfter: stockBefore + item.qty,
          createdBy: si.createdBy,
        });
      }
    });

    setStockItemList(updatedInventory);
    setStockMovementList(prev => [...newMovements, ...prev]);
    addAuditLog({ action: 'STOCK_IN', module: 'Warehouse', details: `Stock in ${si.noStockIn} processed`, status: 'Success' });
  };

  const addReceiving = (rcv: Receiving) => {
    setReceivingList(prev => [...prev, rcv]);
    
    // 1. Automated inventory entry (Zero Re-typing)
    createStockIn({
      id: `SI-RCV-${Date.now()}`,
      noStockIn: `SI-AUTO-${rcv.noReceiving}`,
      noSuratJalan: rcv.noSuratJalan,
      tanggal: rcv.tanggal,
      type: 'Receiving',
      status: 'Posted',
      createdBy: 'Logistics System',
      items: rcv.items.map(i => ({ 
        kode: i.itemKode || i.id, 
        nama: i.itemName, 
        qty: i.qtyGood || i.qtyReceived || i.qty, 
        satuan: i.unit 
      })),
      noPO: rcv.noPO
    });
    
    // 2. Automated PO status & progress update
    if (rcv.poId) {
      const po = poList.find(p => p.id === rcv.poId);
      if (po) {
        const updatedPOItems = po.items.map(poItem => {
          const receivedItem = rcv.items.find(ri => ri.itemKode === poItem.kode || ri.itemName === poItem.nama);
          if (receivedItem) {
            return {
              ...poItem,
              qtyReceived: (poItem.qtyReceived || 0) + (receivedItem.qtyReceived || 0)
            };
          }
          return poItem;
        });

        const allReceived = updatedPOItems.every(item => (item.qtyReceived || 0) >= item.qty);
        const someReceived = updatedPOItems.some(item => (item.qtyReceived || 0) > 0);
        
        let poStatus: PurchaseOrder['status'] = po.status;
        if (allReceived) poStatus = 'Received'; // Use 'Received' as per PO status types
        else if (someReceived) poStatus = 'Approved'; // Or 'Partial' if we had that status

        updatePO(rcv.poId, { 
          items: updatedPOItems, 
          status: poStatus 
        });
      }
    }

    addAuditLog({
      action: 'MATERIAL_RECEIVED',
      module: 'Procurement',
      details: `Received materials for PO ${rcv.noPO} via GRN ${rcv.noReceiving}`,
      status: 'Success'
    });
  };

  const handleProductionOutput = (woId: string, qty: number, workerName: string) => {
    setWorkOrderList(prevWOs => {
      const updatedWOs = prevWOs.map(wo => {
        if (wo.id === woId) {
          const newCompleted = (wo.completedQty || 0) + qty;
          
          // Automated BOM Consumption (Zero Re-typing)
          if (wo.bom && wo.bom.length > 0) {
            const stockOutItems = wo.bom.map(b => ({
              kode: b.kode || b.id,
              nama: b.nama || b.materialName,
              qty: b.qty * (qty / wo.targetQty),
              satuan: b.unit
            }));

            createStockOut({
              id: `SO-PROD-${Date.now()}`,
              noStockOut: `SO-AUTO-PROD-${wo.woNumber}`,
              noWorkOrder: wo.woNumber,
              projectId: wo.projectId,
              penerima: workerName,
              tanggal: new Date().toISOString().split('T')[0],
              type: 'Project Issue',
              status: 'Posted',
              createdBy: 'Production System',
              items: stockOutItems
            });
          }

          return { ...wo, completedQty: newCompleted, status: newCompleted >= wo.targetQty ? 'Completed' : 'In Progress' };
        }
        return wo;
      });

      // Update project progress
      const targetWO = updatedWOs.find(w => w.id === woId);
      if (targetWO && targetWO.projectId) {
        const projectWOs = updatedWOs.filter(w => w.projectId === targetWO.projectId);
        const totalTarget = projectWOs.reduce((sum, w) => sum + w.targetQty, 0);
        const totalCompleted = projectWOs.reduce((sum, w) => sum + (w.completedQty || 0), 0);
        
        if (totalTarget > 0) {
          const newProgress = Math.round((totalCompleted / totalTarget) * 100);
          setProjectList(prevProjects => prevProjects.map(p => 
            p.id === targetWO.projectId ? { ...p, progress: newProgress } : p
          ));
        }
      }

      return updatedWOs;
    });
  };

  const addProductionReport = (report: ProductionReport) => {
    setProductionReportList(prev => [report, ...prev]);
    // Link to WO progress automatically
    if (report.woNumber) {
      const wo = workOrderList.find(w => w.woNumber === report.woNumber);
      if (wo) {
        handleProductionOutput(wo.id, report.outputQty, report.workerName);
      }
    }
  };
  const addBeritaAcara = (ba: BeritaAcara) => setBeritaAcaraList(prev => [...prev, ba]);
  const updateBeritaAcara = (id: string, updates: Partial<BeritaAcara>) => setBeritaAcaraList(prev => prev.map(ba => ba.id === id ? { ...ba, ...updates } : ba));
  const deleteBeritaAcara = (id: string) => setBeritaAcaraList(prev => prev.filter(ba => ba.id !== id));
  
  const addQuotation = (q: Quotation) => setQuotationList(prev => [...prev, q]);
  const updateQuotation = (id: string, updates: Partial<Quotation>) => setQuotationList(prev => prev.map(q => q.id === id ? { ...q, ...updates } : q));
  const deleteQuotation = (id: string) => setQuotationList(prev => prev.filter(q => q.id !== id));
  const addSuratJalan = (sj: SuratJalan) => setSuratJalanList(prev => [...prev, sj]);
  const updateSuratJalan = (id: string, updates: Partial<SuratJalan>) => setSuratJalanList(prev => prev.map(sj => sj.id === id ? { ...sj, ...updates } : sj));
  const deleteSuratJalan = (id: string) => setSuratJalanList(prev => prev.filter(sj => sj.id !== id));
  const addAsset = (a: Asset) => setAssetList(prev => [...prev, a]);
  const addMaintenance = (m: MaintenanceRecord) => {
    setMaintenanceList(prev => [m, ...prev]);
    addAuditLog({
      action: 'MAINTENANCE_LOGGED',
      module: 'Assets',
      details: `Recorded maintenance ${m.maintenanceNo} for unit ${m.equipmentName}`,
      status: 'Success'
    });
  };
  const updateAsset = (id: string, updates: Partial<Asset>) => setAssetList(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
  const deleteAsset = (id: string) => setAssetList(prev => prev.filter(a => a.id !== id));

  const addInvoice = (inv: Invoice) => setInvoiceList(prev => [...prev, inv]);
  const updateInvoice = (id: string, updates: Partial<Invoice>) => setInvoiceList(prev => prev.map(inv => inv.id === id ? { ...inv, ...updates } : inv));
  const updatePO = (id: string, updates: Partial<any>) => setPoList(prev => prev.map(po => po.id === id ? { ...po, ...updates } : po));
  const approveProject = (id: string, ownerName: string) => setProjectList(prev => prev.map(p => p.id === id ? { ...p, approvalStatus: 'Approved', approvedBy: ownerName, approvedAt: new Date().toISOString() } : p));
  const updateMaterialRequest = (id: string, updates: Partial<MaterialRequest>) => setMaterialRequestList(prev => prev.map(mr => mr.id === id ? { ...mr, ...updates } : mr));
  const issueMaterialRequest = (id: string, issuedBy: string) => setMaterialRequestList(prev => prev.map(mr => mr.id === id ? { ...mr, status: 'Issued' } : mr));
  const addDataCollection = (dc: DataCollection) => setDataCollectionList(prev => [...prev, dc]);
  const updateDataCollection = (id: string, updates: Partial<DataCollection>) => setDataCollectionList(prev => prev.map(dc => dc.id === id ? { ...dc, ...updates } : dc));
  const deleteDataCollection = (id: string) => setDataCollectionList(prev => prev.filter(dc => dc.id !== id));
  const addProject = (p: Project) => setProjectList(prev => [...prev, p]);
  const deleteProject = (id: string) => setProjectList(prev => prev.filter(p => p.id !== id));
  const addVendorInvoice = (inv: VendorInvoice) => setVendorInvoiceList(prev => [...prev, inv]);
  const updateVendorInvoice = (id: string, updates: Partial<VendorInvoice>) => setVendorInvoiceList(prev => prev.map(inv => inv.id === id ? { ...inv, ...updates } : inv));
  const generatePayroll = (month: string, year: string) => {
    setPayrollList(prev => [{ id: `PAY-${Date.now()}`, month, year: parseInt(year), totalPayroll: 0, status: 'Pending', employeeCount: 0 }, ...prev]);
  };
  const addSuratMasuk = (s: SuratMasuk) => setSuratMasukList(prev => [...prev, s]);
  const updateSuratMasuk = (id: string, updates: Partial<SuratMasuk>) => setSuratMasukList(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  const deleteSuratMasuk = (id: string) => setSuratMasukList(prev => prev.filter(s => s.id !== id));
  const addSuratKeluar = (s: SuratKeluar) => setSuratKeluarList(prev => [...prev, s]);
  const updateSuratKeluar = (id: string, updates: Partial<SuratKeluar>) => setSuratKeluarList(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  const deleteSuratKeluar = (id: string) => setSuratKeluarList(prev => prev.filter(s => s.id !== id));

  const addEquipmentUsage = (usage: EquipmentUsage) => {
    setProjectList(prev => prev.map(p => {
      if (p.id === usage.projectId) {
        return { ...p, equipmentUsage: [...(p.equipmentUsage || []), usage] };
      }
      return p;
    }));
    addAuditLog({
      action: 'EQUIPMENT_USAGE_LOG',
      module: 'Operations',
      details: `Logged ${usage.hoursUsed}h for ${usage.equipmentName} on project ${usage.projectId}`,
      status: 'Success'
    });
  };

  const addMaterialRequest = (request: MaterialRequest) => {
    // Sync both global list and project internal list
    setMaterialRequestList(prev => [...prev, request]);
    setProjectList(prev => prev.map(p => {
      if (p.id === request.projectId) {
        return { ...p, materialRequests: [...(p.materialRequests || []), request] };
      }
      return p;
    }));
    addAuditLog({
      action: 'MATERIAL_REQUEST_SUBMITTED',
      module: 'Procurement',
      details: `Requested ${request.quantity} ${request.unit} of ${request.itemName} for project ${request.projectId}`,
      status: 'Success'
    });
  };

  const updateMaterialRequestStatus = (projectId: string, requestId: string, status: MaterialRequest['status']) => {
    // Sync both global list and project internal list
    setMaterialRequestList(prev => prev.map(r => r.id === requestId ? { ...r, status } : r));
    setProjectList(prev => prev.map(p => {
      if (p.id === projectId) {
        const updatedRequests = (p.materialRequests || []).map(r => 
          r.id === requestId ? { ...r, status } : r
        );
        return { ...p, materialRequests: updatedRequests };
      }
      return p;
    }));
  };

  const addStockIn = (si: StockIn) => createStockIn(si);
  const addStockOut = (so: StockOut) => createStockOut(so);
  const recordProduction = async (woId: string, qty: number) => handleProductionOutput(woId, qty, currentUser?.fullName || 'System');

  const convertDataCollectionToQuotation = (dcId: string) => {
    const dc = dataCollectionList.find(d => d.id === dcId);
    if (!dc) return;

    const newQuo: Quotation = {
      id: `QUO-${Date.now()}`,
      nomorQuotation: `QUO/GTP/${new Date().getFullYear()}/${(quotationList.length + 1).toString().padStart(3, '0')}`,
      tanggal: new Date().toISOString().split('T')[0],
      customer: {
        nama: dc.namaResponden,
        alamat: dc.lokasi,
      },
      perihal: dc.tipePekerjaan,
      grandTotal: 0, // Needs calculation in UI
      status: 'Draft',
      materials: dc.materials?.map(m => ({ ...m, unitPrice: 0, total: 0 })),
      manpower: dc.manpower?.map(m => ({ ...m, unitPrice: 0, total: 0 })),
      equipment: dc.equipment?.map(e => ({ ...e, unitPrice: 0, total: 0 })),
      dataCollectionId: dc.id,
      type: dc.jenisKontrak === 'Project' ? 'Project' : 'Direct'
    };

    setQuotationList(prev => [...prev, newQuo]);
    updateDataCollection(dcId, { status: 'Completed' });
    toast.success("Survey data converted to Quotation Draft successfully!");
  };

  const convertQuotationToProject = (quoId: string) => {
    const quo = quotationList.find(q => q.id === quoId);
    if (!quo) return;

    const newProj: Project = {
      id: `PRJ-${Date.now()}`,
      kodeProject: `GTP-PRJ-${new Date().getFullYear()}-${(projectList.length + 1).toString().padStart(3, '0')}`,
      namaProject: quo.perihal,
      customer: quo.customer?.nama || 'N/A',
      nilaiKontrak: quo.grandTotal,
      status: 'In Progress',
      progress: 0,
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      quotationId: quo.id,
      boq: quo.materials?.map(m => ({
        materialName: m.materialName || m.description,
        itemKode: m.itemKode || m.id,
        qtyEstimate: m.qty,
        qtyActual: 0,
        unit: m.unit,
        unitPrice: m.unitPrice
      })),
      materialRequests: [],
      workingExpenses: [],
      fieldAttendance: []
    };

    setProjectList(prev => [...prev, newProj]);
    updateQuotation(quoId, { status: 'Approved' });
    toast.success("Quotation converted to Active Project successfully!");
  };

  const applyTemplate = (templateId: string, variables: Record<string, string>) => {
    const template = templateSuratList.find(t => t.id === templateId);
    if (!template) return "";
    let content = template.content;
    Object.entries(variables).forEach(([key, val]) => {
      content = content.replace(`{{${key}}}`, val);
    });
    return content;
  };

  const updateReservedStock = (materials: any[], type: 'reserve' | 'release') => {
    setStockItemList(prev => prev.map(item => {
      const mat = materials.find(m => m.kode === item.kode);
      if (mat) {
        return { ...item, stok: type === 'reserve' ? item.stok - mat.qty : item.stok + mat.qty };
      }
      return item;
    }));
  };

  const refreshAll = () => {
    if (auditLogs.length === 0) {
      setAuditLogs([
        {
          id: 'LOG-1',
          timestamp: new Date().toISOString(),
          userId: '1',
          userName: 'Administrator',
          action: 'SYSTEM_BOOT',
          module: 'Kernel',
          details: 'ERP System Premium Warehouse Ledger initialized',
          status: 'Success'
        },
        {
          id: 'LOG-2',
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          userId: '1',
          userName: 'Administrator',
          action: 'STOCK_SYNC',
          module: 'Warehouse',
          details: 'Sinkronisasi stok otomatis berhasil dilakukan',
          status: 'Success'
        }
      ]);
    }
    if (userList.length === 0) {
      setUserList([
        { id: '1', username: 'admin', fullName: 'Administrator', role: 'Admin', status: 'Active', password: 'admin123' },
        { id: '3', username: 'finance', fullName: 'Finance Manager', role: 'Finance', status: 'Active', password: 'finance123' },
      ]);
    }
    if (projectList.length === 0) {
      setProjectList([
        {
          id: 'PRJ-2026-001',
          kodeProject: 'GTP-CIV-001',
          namaProject: 'Pembangunan Gudang Logistik B',
          customer: 'PT Indofood CBP Sukses Makmur',
          nilaiKontrak: 2500000000,
          status: 'In Progress',
          progress: 45,
          endDate: '2026-08-15',
          approvalStatus: 'Approved',
          boq: [
            { materialName: 'Portland Cement', itemKode: 'MAT-001', qtyEstimate: 200, qtyActual: 50, unit: 'Sack', unitPrice: 65000 },
            { materialName: 'Bata Merah', itemKode: 'MAT-002', qtyEstimate: 5000, qtyActual: 1000, unit: 'Pcs', unitPrice: 1200 }
          ],
          workingExpenses: [
            { id: 'EXP-1', projectId: 'PRJ-2026-001', date: '2026-02-01', description: 'Biaya Mobilisasi Tim', nominal: 15000000, hasNota: true, category: 'Operational' },
            { id: 'EXP-2', projectId: 'PRJ-2026-001', date: '2026-02-05', description: 'Konsumsi Lapangan Minggu 1', nominal: 5000000, hasNota: true, category: 'Operational' }
          ],
          fieldAttendance: [],
          materialUsageReports: [
            {
              id: 'MUR-001',
              projectId: 'PRJ-2026-001',
              reportNumber: 'MUR/001/GTP/2026',
              date: '2026-02-12',
              items: [
                { materialName: 'Portland Cement', qtyUsed: 50, unit: 'Sack' },
                { materialName: 'Bata Merah', qtyUsed: 1000, unit: 'Pcs' }
              ]
            }
          ]
        }
      ]);
    }
    if (quotationList.length === 0) {
      setQuotationList([
        {
          id: 'QO-2026-001',
          nomorQuotation: '001/GTP/QUO/I/2026',
          tanggal: '2026-02-10',
          customer: {
            nama: 'PT Indah Kiat Pulp & Paper Tbk',
            alamat: 'Jl. Raya Serang KM 71, Kragilan, Serang',
            pic: 'Bpk. Hendra'
          },
          perihal: 'Refractory Repair & Maintenance Boiler #4',
          grandTotal: 1250000000,
          status: 'Draft',
          materials: [
            { id: 'm1', description: 'Technocast Castable Trowelable', qty: 150, unit: 'Sack', unitPrice: 250000, total: 37500000 },
            { id: 'm2', description: 'Insulating Fire Brick B1', qty: 500, unit: 'Pcs', unitPrice: 45000, total: 22500000 }
          ],
          manpower: [
            { id: 'w1', description: 'Supervisor Refractory', qty: 1, unit: 'Man-Day', unitPrice: 1500000, total: 15000000 },
            { id: 'w2', description: 'Bricklayer Specialist', qty: 4, unit: 'Man-Day', unitPrice: 850000, total: 34000000 }
          ],
          equipment: [],
          consumables: []
        }
      ]);
    }

    if (workOrderList.length === 0) {
      setWorkOrderList([
        {
          id: 'WO-001',
          woNumber: 'SPK/GTP/2026/001',
          projectId: 'PRJ-2026-001',
          projectName: 'Pembangunan Gudang Logistik B',
          itemToProduce: 'Pondasi Struktur Utama',
          targetQty: 100,
          completedQty: 45,
          status: 'In Progress',
          priority: 'Urgent',
          deadline: '2026-03-30',
          leadTechnician: 'DEDE IRWAN'
        }
      ]);
    }
    if (stockItemList.length === 0) {
      setStockItemList([
        { id: 'ST-001', kode: 'MTL-001', nama: 'Semen Tiga Roda 50kg', stok: 500, satuan: 'Sack', kategori: 'Material', minStock: 50, hargaSatuan: 65000, lokasi: 'Gudang Utama' },
        { id: 'ST-002', kode: 'MTL-002', nama: 'Baja WF 200', stok: 24, satuan: 'Batang', kategori: 'Besi/Baja', minStock: 5, hargaSatuan: 4500000, lokasi: 'Area Terbuka' },
        { id: 'ST-003', kode: 'TL-001', nama: 'Mesin Las Lincoln', stok: 2, satuan: 'Unit', kategori: 'Tools', minStock: 1, hargaSatuan: 12000000, lokasi: 'Tool Room' },
      ]);
    }
    if (archiveRegistry.length === 0) {
      setArchiveRegistry([
        { id: 'REC-001', date: '2025-11-14', ref: 'INV/GTP/2025/11/001', description: 'Pembayaran Vendor Baja Utama', amount: 125000000, project: 'Warehouse Cikande', admin: 'Aris S.', type: 'AP', source: 'Finance' },
      ]);
    }
    if (employeeList.length === 0) {
      const initialEmployees: Employee[] = [
        { id: 'EMP-001', employeeId: 'GTP-ENG-001', name: 'AJI TEJA PRATAMA', position: 'Engineer', department: 'Operations', employmentType: 'Permanent', joinDate: '2024-01-15', email: 'aji.teja@gemateknik.co.id', phone: '082161296172', address: 'Bekasi', emergencyContact: 'Elis Supriyati', emergencyPhone: '082161296172', salary: 8500000, status: 'Active' },
        { id: 'EMP-002', employeeId: 'GTP-SPC-001', name: 'SATRIO PURWANTO', position: 'Personal API Specialist', department: 'Operations', employmentType: 'Contract', joinDate: '2024-02-10', email: 'satrio.p@gemateknik.co.id', phone: '0895334055952', address: 'Serang', emergencyContact: 'Siti Fartiah', emergencyPhone: '0895334055952', salary: 9000000, status: 'Active' },
        { id: 'EMP-003', employeeId: 'GTP-SAF-001', name: 'RENDY TRISUKMA', position: 'Safety Man', department: 'Operations', employmentType: 'Permanent', joinDate: '2024-03-05', email: 'rendy.t@gemateknik.co.id', phone: '087878238001', address: 'Bekasi', emergencyContact: 'Etty Hardiana', emergencyPhone: '087878238001', salary: 7500000, status: 'Active' },
        { id: 'EMP-004', employeeId: 'GTP-THL-001', name: 'ABDUL AZIS', position: 'Tukang Kayu', department: 'Operations', employmentType: 'THL', joinDate: '2024-05-12', email: 'abdul.azis@gemateknik.co.id', phone: '083816708454', address: 'Purwakarta', emergencyContact: 'Aminah', emergencyPhone: '083816708454', salary: 4500000, status: 'Active' },
        { id: 'EMP-005', employeeId: 'GTP-THL-002', name: 'ABDUL LATIF HIDAYAT', position: 'Tukang Kayu', department: 'Operations', employmentType: 'THL', joinDate: '2024-05-12', email: 'abdul.latif@gemateknik.co.id', phone: '083817781690', address: 'Purwakarta', emergencyContact: 'Yoyoh', emergencyPhone: '083817781690', salary: 4500000, status: 'Active' },
        { id: 'EMP-006', employeeId: 'GTP-THL-003', name: 'DADAN', position: 'Tukang Kayu', department: 'Operations', employmentType: 'THL', joinDate: '2024-05-15', email: 'dadan@gemateknik.co.id', phone: '087821008105', address: 'Purwakarta', emergencyContact: 'Yoyoh', emergencyPhone: '087821008105', salary: 4500000, status: 'Active' },
        { id: 'EMP-007', employeeId: 'GTP-THL-004', name: 'DADANG WAHYUDIN', position: 'Tukang Kayu', department: 'Operations', employmentType: 'THL', joinDate: '2024-05-20', email: 'dadang.w@gemateknik.co.id', phone: '087882808093', address: 'Purwakarta', emergencyContact: 'Iyum', emergencyPhone: '087882808093', salary: 4500000, status: 'Active' },
        { id: 'EMP-008', employeeId: 'GTP-THL-005', name: 'DEDE IRWAN', position: 'Tukang Batu', department: 'Operations', employmentType: 'THL', joinDate: '2024-06-01', email: 'dede.i@gemateknik.co.id', phone: '083112609696', address: 'Purwakarta', emergencyContact: 'Ooy', emergencyPhone: '083112609696', salary: 4200000, status: 'Active' },
        { id: 'EMP-009', employeeId: 'GTP-THL-006', name: 'EDI KURNAEDI', position: 'Tukang Batu', department: 'Operations', employmentType: 'THL', joinDate: '2024-06-05', email: 'edi.k@gemateknik.co.id', phone: '083819033142', address: 'Purwakarta', emergencyContact: 'Rosidah', emergencyPhone: '083819033142', salary: 4200000, status: 'Active' },
        { id: 'EMP-010', employeeId: 'GTP-THL-007', name: 'HERI TARYANA', position: 'Tukang Batu', department: 'Operations', employmentType: 'THL', joinDate: '2024-06-10', email: 'heri.t@gemateknik.co.id', phone: '083875331977', address: 'Purwakarta', emergencyContact: 'Siti Saadah', emergencyPhone: '083875331977', salary: 4200000, status: 'Active' },
        { id: 'EMP-011', employeeId: 'GTP-THL-008', name: 'SEFTIAN SANGGA DEWA', position: 'Pekerja', department: 'Operations', employmentType: 'THL', joinDate: '2024-07-01', email: 'seftian.s@gemateknik.co.id', phone: '083133604758', address: 'Purwakarta', emergencyContact: 'Imas Setiasih', emergencyPhone: '083133604758', salary: 3800000, status: 'Active' },
        { id: 'EMP-012', employeeId: 'GTP-THL-009', name: 'SUHENDAR', position: 'Pekerja', department: 'Operations', employmentType: 'THL', joinDate: '2024-07-05', email: 'suhendar@gemateknik.co.id', phone: '083866057696', address: 'Purwakarta', emergencyContact: 'Aah', emergencyPhone: '083866057696', salary: 3800000, status: 'Active' },
        { id: 'EMP-013', employeeId: 'GTP-THL-010', name: 'WAWAN', position: 'Pekerja', department: 'Operations', employmentType: 'THL', joinDate: '2024-07-10', email: 'wawan@gemateknik.co.id', phone: '083896016661', address: 'Purwakarta', emergencyContact: 'Yani', emergencyPhone: '083896016661', salary: 3800000, status: 'Active' },
      ];
      setEmployeeList(initialEmployees);
    }
  };

  const resetAllData = () => {
    setProjectList([]);
    setInvoiceList([]);
    setStockItemList([]);
    setEmployeeList([]);
    setAttendanceList([]);
    setArchiveRegistry([]);
    refreshAll();
  };

  // Vendor Management Functions
  const addVendor = (vendor: Vendor) => {
    setVendorList(prev => [...prev, vendor]);
    toast.success(`Vendor ${vendor.namaVendor} berhasil ditambahkan!`);
    addAuditLog({
      action: 'Vendor Added',
      module: 'Finance',
      details: `Menambahkan vendor baru: ${vendor.namaVendor}`,
      status: 'Success'
    });
  };

  const updateVendor = (id: string, updates: Partial<Vendor>) => {
    setVendorList(prev => prev.map(v => v.id === id ? { ...v, ...updates } : v));
    addAuditLog({
      action: 'Vendor Updated',
      module: 'Finance',
      details: `Update vendor: ${updates.namaVendor || id}`,
      status: 'Success'
    });
  };

  const deleteVendor = (id: string) => {
    const vendor = vendorList.find(v => v.id === id);
    setVendorList(prev => prev.filter(v => v.id !== id));
    addAuditLog({
      action: 'Vendor Deleted',
      module: 'Finance',
      details: `Menghapus vendor: ${vendor?.namaVendor}`,
      status: 'Success'
    });
  };

  // Expense Management Functions
  const addExpense = (expense: VendorExpense) => {
    setExpenseList(prev => [...prev, expense]);
    addAuditLog({
      action: 'Expense Added',
      module: 'Finance',
      details: `Menambahkan expense baru: ${expense.noExpense} - ${expense.keterangan} (Rp ${expense.totalNominal.toLocaleString('id-ID')})`,
      status: 'Success'
    });
  };

  const updateExpense = (id: string, updates: Partial<VendorExpense>) => {
    setExpenseList(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
  };

  const deleteExpense = (id: string) => {
    const expense = expenseList.find(e => e.id === id);
    setExpenseList(prev => prev.filter(e => e.id !== id));
    addAuditLog({
      action: 'Expense Deleted',
      module: 'Finance',
      details: `Menghapus expense: ${expense?.noExpense}`,
      status: 'Success'
    });
  };

  const approveExpense = (id: string, approver: string) => {
    setExpenseList(prev => prev.map(e => 
      e.id === id 
        ? { ...e, status: 'Approved', approvedBy: approver, approvedAt: new Date().toISOString() }
        : e
    ));
    const expense = expenseList.find(e => e.id === id);
    toast.success(`Expense ${expense?.noExpense} telah disetujui!`);
    addAuditLog({
      action: 'Expense Approved',
      module: 'Finance',
      details: `Menyetujui expense: ${expense?.noExpense} - Rp ${expense?.totalNominal.toLocaleString('id-ID')}`,
      status: 'Success'
    });
  };

  const rejectExpense = (id: string, reason: string) => {
    setExpenseList(prev => prev.map(e => 
      e.id === id 
        ? { 
            ...e, 
            status: 'Rejected', 
            rejectedBy: currentUser?.fullName || 'System',
            rejectedAt: new Date().toISOString(),
            rejectReason: reason
          }
        : e
    ));
    const expense = expenseList.find(e => e.id === id);
    toast.error(`Expense ${expense?.noExpense} ditolak!`);
    addAuditLog({
      action: 'Expense Rejected',
      module: 'Finance',
      details: `Menolak expense: ${expense?.noExpense} - Alasan: ${reason}`,
      status: 'Warning'
    });
  };

  // Customer Management Functions
  const addCustomer = (customer: Customer) => {
    setCustomerList(prev => [...prev, customer]);
    toast.success(`Customer ${customer.namaCustomer} berhasil ditambahkan!`);
    addAuditLog({
      action: 'Customer Added',
      module: 'Finance',
      details: `Menambahkan customer baru: ${customer.namaCustomer}`,
      status: 'Success'
    });
  };

  const updateCustomer = (id: string, updates: Partial<Customer>) => {
    setCustomerList(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
    addAuditLog({
      action: 'Customer Updated',
      module: 'Finance',
      details: `Mengupdate data customer`,
      status: 'Success'
    });
  };

  const deleteCustomer = (id: string) => {
    const customer = customerList.find(c => c.id === id);
    setCustomerList(prev => prev.filter(c => c.id !== id));
    addAuditLog({
      action: 'Customer Deleted',
      module: 'Finance',
      details: `Menghapus customer: ${customer?.namaCustomer}`,
      status: 'Success'
    });
  };

  // Customer Invoice Management Functions
  const addCustomerInvoice = (invoice: CustomerInvoice) => {
    setCustomerInvoiceList(prev => [...prev, invoice]);
    toast.success(`Invoice ${invoice.noInvoice} berhasil dibuat!`);
    addAuditLog({
      action: 'Invoice Created',
      module: 'Finance',
      details: `Membuat invoice baru: ${invoice.noInvoice} - ${invoice.customerName} - Rp ${invoice.totalNominal.toLocaleString('id-ID')}`,
      status: 'Success'
    });
  };

  const updateCustomerInvoice = (id: string, updates: Partial<CustomerInvoice>) => {
    setCustomerInvoiceList(prev => prev.map(inv => inv.id === id ? { ...inv, ...updates } : inv));
    const invoice = customerInvoiceList.find(inv => inv.id === id);
    if (updates.status === 'Sent') {
      toast.success(`Invoice ${invoice?.noInvoice} berhasil dikirim!`);
      addAuditLog({
        action: 'Invoice Sent',
        module: 'Finance',
        details: `Mengirim invoice: ${invoice?.noInvoice} ke ${invoice?.customerName}`,
        status: 'Success'
      });
    }
  };

  const deleteCustomerInvoice = (id: string) => {
    const invoice = customerInvoiceList.find(inv => inv.id === id);
    setCustomerInvoiceList(prev => prev.filter(inv => inv.id !== id));
    toast.success(`Invoice ${invoice?.noInvoice} berhasil dihapus!`);
    addAuditLog({
      action: 'Invoice Deleted',
      module: 'Finance',
      details: `Menghapus invoice: ${invoice?.noInvoice}`,
      status: 'Success'
    });
  };

  const addInvoicePayment = (invoiceId: string, payment: InvoicePayment) => {
    setCustomerInvoiceList(prev => prev.map(inv => {
      if (inv.id === invoiceId) {
        const newPaidAmount = inv.paidAmount + payment.nominal;
        const newOutstanding = inv.totalNominal - newPaidAmount;
        const newStatus = newOutstanding === 0 ? 'Paid' : 'Partial Paid';
        
        return {
          ...inv,
          paidAmount: newPaidAmount,
          outstandingAmount: newOutstanding,
          status: newStatus as any,
          paymentHistory: [...inv.paymentHistory, payment]
        };
      }
      return inv;
    }));

    const invoice = customerInvoiceList.find(inv => inv.id === invoiceId);
    toast.success(`Pembayaran Rp ${payment.nominal.toLocaleString('id-ID')} berhasil dicatat!`);
    addAuditLog({
      action: 'Payment Received',
      module: 'Finance',
      details: `Menerima pembayaran invoice ${invoice?.noInvoice} sebesar Rp ${payment.nominal.toLocaleString('id-ID')}`,
      status: 'Success'
    });
  };

  useEffect(() => {
    refreshAll();
  }, []);

  return (
    <AppContext.Provider
      value={{
        projectList,
        invoiceList,
        stockItemList,
        employeeList,
        attendanceList,
        workOrderList,
        productionReportList,
        productionTrackerList,
        qcInspectionList,
        stockInList,
        stockOutList,
        stockMovementList,
        receivingList,
        suratJalanList,
        assetList,
        quotationList,
        poList,
        vendorInvoiceList,
        userList,
        materialRequestList,
        maintenanceList,
        dataCollectionList,
        payrollList,
        suratMasukList,
        suratKeluarList,
        beritaAcaraList,
        templateSuratList,
        archiveRegistry,
        auditLogs,
        vendorList,
        expenseList,
        currentUser,
        login,
        addAuditLog,
        updateUser,
        updateProject,
        addEmployee,
        updateEmployee,
        deleteEmployee,
        addAttendance,
        addAttendanceBulk,
        updateAttendance,
        deleteAttendance,
        recordProduction,
        addQCInspection,
        addWorkOrder,
        updateWorkOrder,
        deleteWorkOrder,
        createStockIn,
        createStockOut,
        addStockIn,
        addStockOut,
        addReceiving,
        addInvoice,
        updateInvoice,
        addProductionReport,
        handleProductionOutput,
        updatePO,
        approveProject,
        updateMaterialRequest,
        issueMaterialRequest,
        addDataCollection,
        updateDataCollection,
        deleteDataCollection,
        addProject,
        deleteProject,
        addQuotation,
        updateQuotation,
        deleteQuotation,
        addVendorInvoice,
        updateVendorInvoice,
        generatePayroll,
        addSuratMasuk,
        updateSuratMasuk,
        deleteSuratMasuk,
        addSuratKeluar,
        updateSuratKeluar,
        deleteSuratKeluar,
        addBeritaAcara,
        updateBeritaAcara,
        deleteBeritaAcara,
        addSuratJalan,
        updateSuratJalan,
        deleteSuratJalan,
        addAsset,
        addMaintenance,
        updateAsset,
        deleteAsset,
        addArchiveEntry,
        addEquipmentUsage,
        addMaterialRequest,
        updateMaterialRequestStatus,
        convertDataCollectionToQuotation,
        convertQuotationToProject,
        applyTemplate,
        updateReservedStock,
        setStockItemList,
        setStockMovementList,
        refreshAll,
        resetAllData,
        alerts,
        markAlertAsRead,
        addVendor,
        updateVendor,
        deleteVendor,
        addExpense,
        updateExpense,
        deleteExpense,
        approveExpense,
        rejectExpense,
        customerList,
        customerInvoiceList,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        addCustomerInvoice,
        updateCustomerInvoice,
        deleteCustomerInvoice,
        addInvoicePayment,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
};
